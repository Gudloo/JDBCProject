package com.example.demo.Service;
import com.example.demo.Entity.Plan;
import com.example.demo.Repository.PlanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PlanService {

    @Autowired
    private PlanRepository planRepository;

    public List<Plan> getAllPlans() {
        return planRepository.findAll();
    }

    public void activatePlan(Long planId, String startTime, String endTime) {
        // Implement activation logic here, e.g., update database
        // You can add more logic as per your requirements
    }
}
