package com.example.demo.Controller;

import com.example.demo.Entity.Plan;
import com.example.demo.Service.PlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/plans")
public class PlanController {

    @Autowired
    private PlanService planService;

    @GetMapping
    public List<Plan> getAllPlans() {
        return planService.getAllPlans();
    }

    @PostMapping("/{planId}/activate")
    public void activatePlan(
            @PathVariable Long planId,
            @RequestParam String startTime,
            @RequestParam String endTime
    ) {
        planService.activatePlan(planId, startTime, endTime);
    }
}

